// import { Profile } from "./Profile";

// export type TelephoneProps = {
//   id: string;

//   telephone: String[];
//   whatsapp: String[];

//   readonly profile?: Profile;
// };

// export class Telephone {
//   private constructor(private props: TelephoneProps) {}

//   public static with(props: TelephoneProps) {
//     return new Telephone(props);
//   }

//   public get id() {
//     return this.props.id;
//   }
//   public get telephone() {
//     return this.props.telephone;
//   }
//   public get whatsapp() {
//     return this.props.whatsapp;
//   }

//   public get profile() {
//     return this.props.profile;
//   }
// }
